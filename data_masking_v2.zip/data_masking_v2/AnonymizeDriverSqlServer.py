import urllib
import pyodbc
import pandas as pd
import sqlalchemy as sqlalchemy
from faker import Factory
import collections
import argparse
import time
import logging


log = logging.getLogger()
handler = logging.StreamHandler()
formatter = logging.Formatter('%(asctime)s %(filename)-2s %(levelname)-2s %(message)s')
handler.setFormatter(formatter)
log.addHandler(handler)
log.setLevel(logging.INFO)

pd.options.mode.chained_assignment = None

arg = argparse.ArgumentParser(description="Data Masking")
arg.add_argument("--config_file", required=True, help="Input Path to Config File")
arg.add_argument("--source_name", required=False, help="Source System To Consider")

args = arg.parse_args()
configPath = args.config_file
if args.source_name is None:
    src_name = 'all'
else:
    src_name = args.source_name.lower()


if src_name == 'all':
    log.info(f"********************Initiating masking job for {src_name} sources mentioned in config file ********************")
    config_df = pd.read_csv(configPath, sep=';')
    src_names_to_consider = list(set(config_df['SOURCE_NAME']))
    for each_src in src_names_to_consider:
        try:
            config_df = pd.read_csv(configPath, sep=';')
            src_name = each_src.lower()
            log.info(f"********************Source name being processed is {src_name}********************")
            log.info(f"********************Configuration file path is {configPath}********************")
            config_df = config_df[(config_df.SOURCE_NAME == src_name.strip().upper())]
            config_df.fillna('', inplace=True)
            cols = ['SOURCE_NAME', 'KEY']
            config_df['KEYS'] = config_df[cols].apply(lambda row: '_'.join(row.values.astype(str)), axis=1)

            config_df = config_df[['KEYS', 'VALUE']]
            config_df['KEYS'] = config_df['KEYS'].str.lower()
            config_rdd = dict(zip(config_df.KEYS, config_df.VALUE))

            log.info(f"********************Configuration dictionary is {config_rdd}********************")

            src_cols_list = [elem.strip() for elem in config_rdd[src_name.lower() + '_col_names'].split("||")]
            log.info(f"********************Columns to be masked are {src_cols_list}********************")
            faker_cols_list = ["collections.defaultdict(" + elem.strip() + ")" for elem in
                               config_rdd[src_name.lower() + '_faker_names'].split("||")]

            faker = Factory.create()
            source_server = config_rdd[src_name + "_source_server"]


            ###########Custom phone format#################
            def customised_phone_number():
                return faker.numerify('###-###-####')


            def customised_integer():
                return faker.pydecimal(right_digits=0, positive=True, min_value=0, max_value=9999)


            # server = 'USHYDVEDKUM1'
            log.info(f"********************Source server is {source_server}********************")
            source_database = config_rdd[src_name + "_source_db"]
            log.info(f"********************Source database is {source_database}********************")
            # database = 'user_db'
            source_table = config_rdd[src_name + "_source_table"]
            log.info(f"********************Source table is {source_table}********************")

            source_username = config_rdd[src_name + "_source_username"]
            source_password = config_rdd[src_name + "_source_password"]

            filter_condition = config_rdd[src_name + "_source_filter"]
            log.info(f"********************Filter condition to be applied: {filter_condition}********************")

            target_server = config_rdd[src_name + "_target_server"]
            log.info(f"********************Target server is {target_server}********************")
            target_database = config_rdd[src_name + "_target_db"]
            log.info(f"********************Target database is {target_database}********************")
            target_table = config_rdd[src_name + "_target_table"]
            log.info(f"********************Target table is {target_table}********************")
            target_username = config_rdd[src_name + "_target_username"]
            target_password = config_rdd[src_name + "_target_password"]

            log.info(f"********************Connecting to the source database....********************")
            source_cnxn = pyodbc.connect(
                'DRIVER={SQL Server};SERVER=' + source_server + ';DATABASE=' + source_database + ';UID=' + source_username + ';PWD=' + source_password)
            source_cursor = source_cnxn.cursor()

            # query = "SELECT src_name, src_email, src_ssn, src_phone_number, src_type_of_care, src_insurance_type, src_company FROM " + source_table +";"
            query = "SELECT * FROM " + source_table + " WHERE " + filter_condition + ";"
            df = pd.read_sql(query, source_cnxn)
            log.info(f"********************Stored input data in Pandas dataframe********************")

            query_to_retrieve_column_names = \
                "select schema_name(tab.schema_id) as schema_name,\
                tab.name as table_name, \
                col.column_id,\
                col.name as column_name, \
                t.name as data_type,    \
                col.max_length, \
                col.precision \
                from sys.tables as tab \
                inner join sys.columns as col \
                on tab.object_id = col.object_id and tab.name = " + "'" + source_table + "'" + \
                " left join sys.types as t \
                on col.user_type_id = t.user_type_id \
                order by schema_name, \
                table_name,  \
                column_id;"

            log.info(f"********************Executing the below query to retrieve column names********************")
            log.info(query_to_retrieve_column_names)

            column_df = pd.read_sql(query_to_retrieve_column_names, source_cnxn)

            column_name_type_lengths_df = column_df[['column_name', 'data_type', 'max_length']]

            column_list = column_df['column_name'].tolist()

            log.info(f"********************Below are the columns in the source table ********************")
            log.info(column_list)

            # target_cnxn = pyodbc.connect(
            #     'DRIVER={SQL Server};SERVER=' + target_server + ';DATABASE=' + target_database + ';UID=' + target_username + ';PWD=' + target_password)
            # target_cursor = target_cnxn.cursor()

            #############
            import sqlalchemy as sa

            # params = 'DRIVER={ODBC Driver 17 for SQL Server};SERVER='+target_server + ';DATABASE=' + target_database + ';UID=' + target_username + ';PWD=' + target_password
            # db_params = urllib.parse.quote_plus(params)
            # engine = sa.create_engine("mssql+pyodbc:///?odbc_connect={}".format(db_params),fast_executemany=True)
            target_connection_string = 'mssql+pyodbc://' + target_server + '/' + target_database + '?driver=ODBC+Driver+17+for+SQL+Server?Trusted_Connection=yes'
            engine = sa.create_engine(target_connection_string, fast_executemany=True)
            # engine = sa.create_engine('mssql+pyodbc://USHYDVEDKUM1/user_db_target?driver=ODBC+Driver+17+for+SQL+Server?Trusted_Connection=yes', fast_executemany = True)
            target_con = engine.connect()

            ############
            # faker_cols_list = ['collections.defaultdict(faker.email)', 'collections.defaultdict(faker.ssn)', 'collections.defaultdict(faker.phone_number)', 'collections.defaultdict(faker.company)']
            dict4 = dict(zip(src_cols_list, faker_cols_list))
            # print(dict4)

            dict5 = {key: eval(value) for key, value in dict4.items()}


            # print(dict5)

            # Logic to find max length per attribute
            # Need to filter such that column_name == elem and retrieve max_length
            def retrieve_max_length_of_column(col):
                length_in_systypes = \
                    column_name_type_lengths_df.loc[column_name_type_lengths_df['column_name'] == col][
                        'max_length'].tolist()[0]
                data_type_of_column = \
                    column_name_type_lengths_df.loc[column_name_type_lengths_df['column_name'] == col][
                        'data_type'].tolist()[0]
                if data_type_of_column == 'nvarchar':
                    length_to_use = int(length_in_systypes / 2)
                else:
                    length_to_use = int(length_in_systypes)
                return length_to_use, data_type_of_column


            log.info(f"********************Generating Pandas dataframe with masked data ********************")
            start_mask_data = time.process_time()

            for elem in dict5.keys():
                max_length_allowed, data_type_of_elem = retrieve_max_length_of_column(elem)
                if data_type_of_elem in ['char', 'varchar', 'text', 'nchar', 'nvarchar', 'ntext']:
                    df[elem] = df.apply(
                        # lambda row: print('$$$$$$$$$$',(row['country'])), axis = 1)
                        lambda row: (dict5[elem][row[elem]][:max_length_allowed]), axis=1)
                    # print("$$$$$$$$$$$$$$$",row['country'])
                    # ctry =  row['country']
                elif data_type_of_elem in ['bigint', 'numeric', 'bit', 'smallint', 'decimal', 'smallmoney', 'int',
                                           'tinyint',
                                           'money', 'float', 'real']:
                    df[elem] = df.apply(
                        lambda row: int(str(dict5[elem][row[elem]])[:max_length_allowed]), axis=1)

            log.info(f"********************Done with generating Pandas dataframe with masked data ********************")
            log.info(
                f"********************Time taken to generate masked data is {time.process_time() - start_mask_data} seconds ********************")

            # creating column list for insertion
            cols = ",".join([str(i) for i in column_list])

            log.info(f"********************Inserting the target table {target_table} with masked data ********************")

            # start = time.process_time()

            # for index, row in df.iterrows():
            #     # sql = "INSERT INTO " + target_table + "(" + cols + ") VALUES (?,?,?,?,?,?,? )"
            #     sql = "INSERT INTO " + target_table + "(" + cols + ") VALUES (" + "?," * (len(row) - 1) + "?)"
            #     # print(sql)
            #     # target_cursor.execute("INSERT INTO " + target_table + "(src_name,src_email,src_ssn,src_phone_number,src_type_of_care,src_insurance_type , src_company) values(?,?,?,?,?,?,?)", row.src_name,
            #     #                row.src_email, row.src_ssn, row.src_phone_number, row.src_type_of_care, row.src_insurance_type, row.src_company)
            #     target_cursor.execute(sql, tuple(row))
            #
            # target_cnxn.commit()
            # target_cursor.close()

            ####################

            start = time.process_time()

            df.to_sql(target_table, target_con, index=False, if_exists="replace", chunksize=10000)
            log.info(
                f"********************Time taken to insert masked records is {time.process_time() - start} seconds ********************")
            target_con.close()

            ####################

            source_cnxn.commit()
            source_cursor.close()

            log.info(f"#################### Completed inserting the target table {target_table} with masked data ####################")
        except Exception as e:
            log.exception(f"********************Exception found while processing the source {src_name} ********************")
else:
    try:
        config_df = pd.read_csv(configPath, sep=';')
        log.info(f"********************Source name is {src_name}********************")
        log.info(f"********************Configuration file path is {configPath}********************")
        config_df = config_df[(config_df.SOURCE_NAME == src_name.strip().upper())]
        config_df.fillna('', inplace=True)
        cols = ['SOURCE_NAME', 'KEY']
        config_df['KEYS'] = config_df[cols].apply(lambda row: '_'.join(row.values.astype(str)), axis=1)

        config_df = config_df[['KEYS', 'VALUE']]
        config_df['KEYS'] = config_df['KEYS'].str.lower()
        config_rdd = dict(zip(config_df.KEYS, config_df.VALUE))

        log.info(f"********************Configuration dictionary is {config_rdd}********************")

        src_cols_list = [elem.strip() for elem in config_rdd[src_name.lower() + '_col_names'].split("||")]
        log.info(f"********************Columns to be masked are {src_cols_list}********************")
        faker_cols_list = ["collections.defaultdict(" + elem.strip() + ")" for elem in
                           config_rdd[src_name.lower() + '_faker_names'].split("||")]

        faker = Factory.create()
        source_server = config_rdd[src_name + "_source_server"]


        ###########Custom phone format#################
        def customised_phone_number():
            return faker.numerify('###-###-####')


        def customised_integer():
            return faker.pydecimal(right_digits=0, positive=True, min_value=0, max_value=9999)


        # server = 'USHYDVEDKUM1'
        log.info(f"********************Source server is {source_server}********************")
        source_database = config_rdd[src_name + "_source_db"]
        log.info(f"********************Source database is {source_database}********************")
        # database = 'user_db'
        source_table = config_rdd[src_name + "_source_table"]
        log.info(f"********************Source table is {source_table}********************")

        source_username = config_rdd[src_name + "_source_username"]
        source_password = config_rdd[src_name + "_source_password"]

        filter_condition = config_rdd[src_name + "_source_filter"]
        log.info(f"********************Filter condition to be applied: {filter_condition}********************")

        target_server = config_rdd[src_name + "_target_server"]
        log.info(f"********************Target server is {target_server}********************")
        target_database = config_rdd[src_name + "_target_db"]
        log.info(f"********************Target database is {target_database}********************")
        target_table = config_rdd[src_name + "_target_table"]
        log.info(f"********************Target table is {target_table}********************")
        target_username = config_rdd[src_name + "_target_username"]
        target_password = config_rdd[src_name + "_target_password"]

        log.info(f"********************Connecting to the source database....********************")
        source_cnxn = pyodbc.connect(
            'DRIVER={SQL Server};SERVER=' + source_server + ';DATABASE=' + source_database + ';UID=' + source_username + ';PWD=' + source_password)
        source_cursor = source_cnxn.cursor()

        # query = "SELECT src_name, src_email, src_ssn, src_phone_number, src_type_of_care, src_insurance_type, src_company FROM " + source_table +";"
        query = "SELECT * FROM " + source_table + " WHERE " + filter_condition + ";"
        df = pd.read_sql(query, source_cnxn)
        log.info(f"********************Stored input data in Pandas dataframe********************")

        query_to_retrieve_column_names = \
            "select schema_name(tab.schema_id) as schema_name,\
            tab.name as table_name, \
            col.column_id,\
            col.name as column_name, \
            t.name as data_type,    \
            col.max_length, \
            col.precision \
            from sys.tables as tab \
            inner join sys.columns as col \
            on tab.object_id = col.object_id and tab.name = " + "'" + source_table + "'" + \
            " left join sys.types as t \
            on col.user_type_id = t.user_type_id \
            order by schema_name, \
            table_name,  \
            column_id;"

        log.info(f"********************Executing the below query to retrieve column names********************")
        log.info(query_to_retrieve_column_names)

        column_df = pd.read_sql(query_to_retrieve_column_names, source_cnxn)

        column_name_type_lengths_df = column_df[['column_name', 'data_type', 'max_length']]

        column_list = column_df['column_name'].tolist()

        log.info(f"********************Below are the columns in the source table ********************")
        log.info(column_list)

        # target_cnxn = pyodbc.connect(
        #     'DRIVER={SQL Server};SERVER=' + target_server + ';DATABASE=' + target_database + ';UID=' + target_username + ';PWD=' + target_password)
        # target_cursor = target_cnxn.cursor()

        #############
        import sqlalchemy as sa

        # params = 'DRIVER={ODBC Driver 17 for SQL Server};SERVER='+target_server + ';DATABASE=' + target_database + ';UID=' + target_username + ';PWD=' + target_password
        # db_params = urllib.parse.quote_plus(params)
        # engine = sa.create_engine("mssql+pyodbc:///?odbc_connect={}".format(db_params),fast_executemany=True)
        target_connection_string = 'mssql+pyodbc://' + target_server + '/' + target_database + '?driver=ODBC+Driver+17+for+SQL+Server?Trusted_Connection=yes'
        engine = sa.create_engine(target_connection_string, fast_executemany=True)
        # engine = sa.create_engine('mssql+pyodbc://USHYDVEDKUM1/user_db_target?driver=ODBC+Driver+17+for+SQL+Server?Trusted_Connection=yes', fast_executemany = True)
        target_con = engine.connect()

        ############
        # faker_cols_list = ['collections.defaultdict(faker.email)', 'collections.defaultdict(faker.ssn)', 'collections.defaultdict(faker.phone_number)', 'collections.defaultdict(faker.company)']
        dict4 = dict(zip(src_cols_list, faker_cols_list))
        # print(dict4)

        dict5 = {key: eval(value) for key, value in dict4.items()}


        # print(dict5)

        # Logic to find max length per attribute
        # Need to filter such that column_name == elem and retrieve max_length
        def retrieve_max_length_of_column(col):
            length_in_systypes = \
                column_name_type_lengths_df.loc[column_name_type_lengths_df['column_name'] == col]['max_length'].tolist()[0]
            data_type_of_column = \
                column_name_type_lengths_df.loc[column_name_type_lengths_df['column_name'] == col]['data_type'].tolist()[0]
            if data_type_of_column == 'nvarchar':
                length_to_use = int(length_in_systypes / 2)
            else:
                length_to_use = int(length_in_systypes)
            return length_to_use, data_type_of_column


        log.info(f"********************Generating Pandas dataframe with masked data ********************")
        start_mask_data = time.process_time()

        for elem in dict5.keys():
            max_length_allowed, data_type_of_elem = retrieve_max_length_of_column(elem)
            if data_type_of_elem in ['char', 'varchar', 'text', 'nchar', 'nvarchar', 'ntext']:
                df[elem] = df.apply(
                    # lambda row: print('$$$$$$$$$$',(row['country'])), axis = 1)
                    lambda row: (dict5[elem][row[elem]][:max_length_allowed]), axis=1)
                # print("$$$$$$$$$$$$$$$",row['country'])
                # ctry =  row['country']
            elif data_type_of_elem in ['bigint', 'numeric', 'bit', 'smallint', 'decimal', 'smallmoney', 'int', 'tinyint',
                                       'money', 'float', 'real']:
                df[elem] = df.apply(
                    lambda row: int(str(dict5[elem][row[elem]])[:max_length_allowed]), axis=1)

        log.info(f"********************Done with generating Pandas dataframe with masked data ********************")
        log.info(
            f"********************Time taken to generate masked data is {time.process_time() - start_mask_data} seconds ********************")

        # creating column list for insertion
        cols = ",".join([str(i) for i in column_list])

        log.info(f"********************Inserting the target table with masked data ********************")

        # start = time.process_time()

        # for index, row in df.iterrows():
        #     # sql = "INSERT INTO " + target_table + "(" + cols + ") VALUES (?,?,?,?,?,?,? )"
        #     sql = "INSERT INTO " + target_table + "(" + cols + ") VALUES (" + "?," * (len(row) - 1) + "?)"
        #     # print(sql)
        #     # target_cursor.execute("INSERT INTO " + target_table + "(src_name,src_email,src_ssn,src_phone_number,src_type_of_care,src_insurance_type , src_company) values(?,?,?,?,?,?,?)", row.src_name,
        #     #                row.src_email, row.src_ssn, row.src_phone_number, row.src_type_of_care, row.src_insurance_type, row.src_company)
        #     target_cursor.execute(sql, tuple(row))
        #
        # target_cnxn.commit()
        # target_cursor.close()

        ####################

        start = time.process_time()

        df.to_sql(target_table, target_con, index=False, if_exists="replace", chunksize=10000)
        log.info(
            f"********************Time taken to insert masked records is {time.process_time() - start} seconds ********************")
        target_con.close()

        ####################

        source_cnxn.commit()
        source_cursor.close()

        log.info(f"#################### Completed inserting the target table {target_table} with masked data ####################")
    except Exception as e:
        log.exception(f"******************** Exception found while processing the source {src_name} ********************")